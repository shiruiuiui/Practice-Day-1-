import UIKit

var str = "Hello, playground"
print(str)
print("hello shirui")
var f = "Karlie"
var l = "Kloss"
print ( f + l)
print (l + f)
print ("\(f) \(l)")
print ("\(l) \(f)")
print (" I love \(f)")
var a = 12.0
var b = 65.0
var c = 31.0
var d = 98.0
// var e = ((a + b + c + d))
// print ( e / 4.0)
print ((a + b + c + d) / 4)
var m = 10.25
var h = 20
print ( m * Double (h) )
var celeb = "shrek"
print (" Happy Birthday, \(celeb)")
print( 5 < 3 )
print( 12 > 7 )
print (6 != 8)
print( 7 == 7)

print("karlie" == "karlie")
print("karlie" == " karlie")
print("Karlie" == "karlie")

var luckyNum = 7
print(luckyNum < 10)
print(luckyNum == 7)

var favFood = "poke"
if (favFood == "Chipotle")
{
    print ("Chipotle is good!")
}
else if (favFood == "Starbucks")
{
    print (" Startbucks has a lot of sugar!")
}
else if (favFood == "poke")
{
    print ("Poke is so good!")
}
else
{
    print ( "do you have a favorite food?")
}

var hasAccount = false

if (hasAccount == true)
{
    print ("Please log in!")
}
else
{
    print("Let's get some information to create an account for you.")
}
var grade = 6
if (grade >= 0 && grade <= 5)
{
    print ("You're in Elementary School!")
}
else if (grade >= 6 && grade <= 8 )
{
    print ("You're in Middle School")
}
else if (grade >= 9 && grade <= 12)
{
    print ("You're in High School!")
}
else
{
    print ("Please enter a valid integer between 0 and 12.")
}

var numWalks = 0
func walkDog()
{
    print ("put on lease")
    print ("Walk Dog")
    numWalks += 1
    print (numWalks)
    print ("come home")
}
walkDog()
walkDog()

var numBowls = 0
func makeCereal()
{
    print ("Pour cereal into bowl")
    print ("Pour milk into bowl")
    numBowls += 1
    print (numBowls)
    print ("Eat cereal")
    print ("Clean dishes")
}
makeCereal()

func name (name: String)
{
    print ("Hello, \(name)")
}
name(name: "Trinity")

/*
 func walkDogs(numberOfDogs : Int) -> Int
{
    var lengthOfWalks = numberOfDogs * 15
    return lengthOfWalks
    //return numberOfDogs
}

walkDogs(numberOfDogs : 3)
*/

func walkDog(numberOfDogs : Int) -> Int {
    let lengthOfWalk = numberOfDogs * 15
    return lengthOfWalk
}

let minutesToWalk = walkDog(numberOfDogs : 3)
print("Please walk the dogs. I will expect to see you complete that task in \(minutesToWalk) minutes!")

func buyCheese(kindOfCheese: String) -> String
{
    print ("go to store")
    print ("wieght urself beforehand")
    print ("eat the cheese")
    print ("weigh urself after")
    print ("pay cheese in per pound gained" )
    return kindOfCheese
}
var cheeseType = buyCheese(kindOfCheese: "Provolone")
print (cheeseType)
